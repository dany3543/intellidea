class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Escribe un numero");
        int a = Integer.parseInt(System.console().readLine());
        System.out.println("Escribe otro numero");
        int b = Integer.parseInt(System.console().readLine());
        int result = add(a, b);
        System.out.println("La suma de " + a + " y " + b + " es: " + result);
    }
    public static int add(int a, int b) {
        int c=a+b;
        return c;

    }

    public static int subtract(int a, int b) {
        return a - b;
    }
    public static int multiply(int a, int b) {
        return a * b;
    }
    public static int div(int a, int b) {
        return a / b;

    }
}